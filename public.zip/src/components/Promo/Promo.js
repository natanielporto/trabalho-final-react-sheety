import React from 'react';

const Promo = () => {
  return (
    <div>
      <h2>HEYA FELLAS</h2>
    </div>
  );
};

export default Promo;
